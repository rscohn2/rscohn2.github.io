# isrm

Intel Software Repository Manager

Provides a package manager interface to installing Intel Developer
Tools.

## System requirements

cpio, python3, python3-pip

## Installation
        pip install .	

## Use
        isrm -h
	export ACTIVATION_SERIAL_NUMBER=XXXX-YYYYYYYY
	isrm pkg install --activate-serial-number icc

## Development
The -e option allows you install and edit it in place

        pip install -e .

### Testing

We use unittest. Put the tests in isrm/tests. Prefix the file names
with test_. In your tests, import isrm modules using absolute
references. e.g.

        from isrm import rel

#### Test individual files

Run from isrm directory so relative paths work the same

        python -m unittest isrm/parser.py -v

#### Testing everything

Find files that begin with test. Run from isrm directory.

        python -m unittest -v discover -v

#### Testing in docker

Dockerfiles for building images are located in docker subdirectory

To run:

        docker run -e ACTIVATION_SERIAL_NUMBER=XXXX-YYYYYYY -v /local-path-to-isrm:/isrm <docker-image>
        pip install /isrm
