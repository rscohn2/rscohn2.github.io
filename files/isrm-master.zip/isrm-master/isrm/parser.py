# Standard library
import argparse

# Local
from . import cmd

# Would be simpler to inherit from ArgumentParser, but where was some issue
# with keyword arguments that I did not handle correctly
class IsrmParser:
    def __init__(self):
        self.parser = argparse.ArgumentParser('isrm');

        self.parser.add_argument('--verbose', action='store_true', help='emit messages for debugging')
        self.parser.add_argument('--dry-run', action='store_true', help='do not execute commands that change the system')
        self.parser.add_argument('--repo', choices=['yum','apt','irc'], default='irc')
        self.parser.add_argument('--tmp-dir', help='Specify the temporary directory. Must exist. Do not delete it on exit.')
        self.parser.add_argument('--cache-dir', default='isrm_cache')

        cmd.add_arguments(self.parser)

    def parse_args(self,args):
        return self.parser.parse_args(args)

    def print_help(self):
        return self.parser.print_help()
