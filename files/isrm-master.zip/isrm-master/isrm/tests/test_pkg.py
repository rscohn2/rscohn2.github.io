# Standard Library
import unittest

# Local
from isrm import conf
from isrm import package

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class TestPkg(IsrmTestCase):
    def test_read_pkg_data(self):
        p = package.PkgCache()
        
class Cmd(IsrmTestCmd):
    def test_install_tbb_remote_repo(self):
        self.execute_cmd(['pkg','install','--install-dir','/tmp/optintel','tbb'])
        self.execute_cmd(['pkg','uninstall','--install-dir','/tmp/optintel','tbb'])

    def test_install_tbb_local_repo(self):
        self.execute_cmd(['repo','install','--repo-pkg','tbb'])
        self.execute_cmd(['pkg','install','--install-dir','/tmp/optintel','tbb'])
        self.execute_cmd(['pkg','uninstall','--install-dir','/tmp/optintel','tbb'])

    def test_list(self):
        self.execute_cmd(['pkg','list'])

    def test_info(self):
        self.execute_cmd(['pkg','info','tbb','psxe'])

    def test_info_release(self):
        self.execute_cmd(['pkg','info','--release','2019u2','tbb'])
        
