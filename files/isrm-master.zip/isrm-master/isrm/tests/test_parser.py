# Standard Library

# Local

from isrm import parser

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class TestParser(IsrmTestCmd):
    def test_cmds(self):
        examples = [['pkg','install','a'],
                    ['license','install']]
        for example in examples:
            with self.subTest(' '.join(example)):
                args = parser.IsrmParser().parse_args(example)
                self.assertIn('func',args)
