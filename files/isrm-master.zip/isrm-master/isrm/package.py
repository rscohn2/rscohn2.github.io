# Standard Library
from os import path
import pkg_resources

# 3rd party
import yaml

# Local
from . import conf
from . import util

def yml_pkg_path(f):
    return pkg_resources.resource_filename('isrm', path.join('data','pkgs',f))

class WebFile():
    def __init__(self,d):
        self.uri = d['uri']
        self.hash = d['hash']
        
class InstallerInfo():
    def __init__(self,d):
        self.raw = d
        self.components = d['components']
        self.accepts_activation = d['accepts_activation']
        self.silent_cfg = d['silent_cfg']
        self.online = {'linux': WebFile(d['online']['linux'])}
        self.offline = {'linux': WebFile(d['offline']['linux'])}

class ReleaseInfo():
    def __init__(self,name,d):
        util.log('ReleaseInfo: ' + name)
        self.raw = d
        self.name = name
        self.installer = InstallerInfo(d['installer'])
        self.repo_pkgs = d['repo_pkgs']

class ChannelInfo(dict):
    def __init__(self,name,d):
        self.raw = d
        self.name = name
        self.releases = {}

class PkgInfo(dict):
    def __init__(self,name,d):
        util.log('Name: ' + name)
        self.raw = d
        self.name = name
        self.channels = {}
        self.description = d['description']

    def selected_release(self):
        return self.channels[conf.args.channel].releases[conf.args.release]

    def str(self):
        return self.name + ': ' + self.description

class ReleaseCache(dict):
    '''All releases indexed by yml path'''

    def add(self,yml_path):
        if yml_path in self:
            return self[yml_path]

        with open(yml_path,'r') as yml_f:
            release_data = yaml.load(yml_f)
            release = self[yml_path] = ReleaseInfo(release_data['release name'],release_data)
            return release
            
class PkgCache(dict):
    '''All packages indexed by name'''

    def __init__(self,yml_path=None):
        self.release_cache = ReleaseCache()
        if yml_path is None:
            yml_path = yml_pkg_path('pkgs.yml')
        self.read_data(yml_path)
        
    def read_data(self,yml_path):
        yml_dir = path.dirname(yml_path)
        with open(yml_path,'r') as yml_f:
            self.raw = yaml.load(yml_f)
        # Create class instances for all the yaml info
        for pkg_name,pkg_data in self.raw.items():
            util.log('Pkg: ' + pkg_name)
            pkg_data['name'] = pkg_name
            pkg = self[pkg_name] = PkgInfo(pkg_name,pkg_data)
            
            for channel_name,channel_data in pkg_data['channels'].items():
                util.log('  channel: ' + channel_name)
                channel = pkg.channels[channel_name] = ChannelInfo(channel_name, channel_data)
                
                for release_name,release_yml in channel_data['releases'].items():
                    util.log('    release: ' + release_name)
                    release_path = path.join(yml_dir,release_yml)
                    channel.releases[release_name] = self.release_cache.add(release_path)
