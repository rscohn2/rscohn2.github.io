# Standard library

# Local imports
from . import main

main.main()
