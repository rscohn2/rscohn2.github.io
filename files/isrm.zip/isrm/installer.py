# Standard Library
import os
from os import path
import pkg_resources
from string import Template
import tarfile
from urllib import request

# Local
from . import cache
from . import conf
from . import package
from . import util

def unpack(uri, download):
    tf = cache.installer_path(uri)
    unpack_tf = cache.unpacked_installer_path(uri)

    # If the unpacked installer is there, we are done
    if path.exists(unpack_tf):
        return unpack_tf

    # Fetch packed installer if it is not there
    if not path.exists(tf):
        if download:
            print('Fetching: ' + uri)
            with open(tf,'wb') as installer_file:
                response = request.urlopen(uri)
                installer_file.write(response.read())
        else:
            return None

    # Unpack
    tar = tarfile.open(tf)
    tar.extractall(unpack_tf)
    tar.close()

    return unpack_tf

def fetch(repo_pkg_name, download_offline, download_online):
    '''fetch the pset installer'''

    repo_release = package.pkg_cache[repo_pkg_name].selected_release()
    installer = repo_release.installer

    # Use the offline installer if we do not have to fetch it or it
    # was requested
    uri = installer.offline['linux'].uri
    unpack_tf = unpack(uri, download_offline)
    if unpack_tf:
        return (unpack_tf,installer)

    # Use the online installer
    uri = installer.online['linux'].uri
    return (unpack(uri, download_online),installer)

#
# generate silent.cfg to drive installation
#
def expand_pkgs(pkgs):
    '''Translate list of pkgs into list of components'''
    components = []
    for pkg_name in pkgs:
        release = package.pkg_cache[pkg_name].selected_release()
        components.extend(release.installer.components)
    return ';'.join(components)

serial_activation = '''ACTIVATION_SERIAL_NUMBER=$serial_number
ACTIVATION_TYPE=serial_number
'''

def activation_cfg(installer):
    '''Return activation text'''
    env_var_name = 'ACTIVATION_SERIAL_NUMBER'
    if conf.args.activate_serial_number:
        if not installer.accepts_activation:
            util.error('The component does not require activation')
        if not env_var_name in os.environ:
            util.error('To activate with a serial number you must set environment variable ' + env_var_name + ' equal to the serial number')
        return Template(serial_activation).substitute({'serial_number': os.environ[env_var_name]})
    elif installer.accepts_activation:
        return 'ACTIVATION_TYPE=exist_lic\n'
    else:
        return ''

def make_config(installer, pkg_names):
    '''Make a silent.cfg file for pset installer from a template'''
    
    silent_cfg_path = path.join(conf.tmp_dir,'silent.cfg')
    with open(silent_cfg_path,'w') as f_out:
        # for each fragment of the file
        for c in installer.silent_cfg:
            tpl_name = pkg_resources.resource_filename('isrm', path.join('data','cfg',c))
            with open(tpl_name,'r') as f_in:
                tpl = f_in.read()

            # Fill it in
            d = {'pset_install_dir': conf.args.install_dir,
                 'pset_mode': conf.args.pkg_action,
                 'components': expand_pkgs(pkg_names),
                 'activation_cfg': activation_cfg(installer)
            }
            f_out.write(Template(tpl).substitute(d))

    return silent_cfg_path

def run(unpack_path, silent_config_path):
    top = path.splitext(path.basename(unpack_path))[0]
    installer_path = path.join(unpack_path,top,'install.sh')
    util.run([installer_path,'-s',silent_config_path])

def select_repo_pkg(pkgs):
    '''Select the best repo pkg'''
    # if we have already downloaded an offline installer, use it
    for p in pkgs:
        uri = package.pkg_cache[p].selected_release().installer.offline['linux'].uri
        unpack_tf = unpack(uri, download = False)
        if unpack_tf:
            return p
    # otherwise use first in list
    return pkgs[0]
        
def make_install_plan():
    '''Make a plan for installing all software'''
    install_plan = {}
    for pkg_name in conf.args.pkgs:
        util.log('plan for: ' + pkg_name)
        release = package.pkg_cache[pkg_name].selected_release()
        repo_pkg_name = select_repo_pkg(release.repo_pkgs)

        if repo_pkg_name in install_plan:
            install_plan[repo_pkg_name].append(pkg_name)
        else:
            install_plan[repo_pkg_name] = [pkg_name]
    return install_plan
            
def install():
    install_plan = make_install_plan()
    for repo_pkg_name,pkg_names in install_plan.items():
        (unpack_path,installer) = fetch(repo_pkg_name, download_offline=False, download_online=True)
        util.log('Pkg repo: ' + unpack_path)
        silent_config_path = make_config(installer, pkg_names)
        print(conf.args.pkg_action + ' ' + ','.join(pkg_names) + ' with ' + unpack_path)
        run(unpack_path, silent_config_path)
    
