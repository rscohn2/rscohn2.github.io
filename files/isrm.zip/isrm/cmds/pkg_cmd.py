# Standard Library
from os import path
import tarfile
from urllib import request

# Local
from .. import cache
from .. import conf
from .. import installer
from .. import package

def _pkg_install(args):
    installer.install()

def _pkg_list(args):
    for pkg_name in sorted(package.pkg_cache):
        print(package.pkg_cache[pkg_name].str())

def _pkg_info(args):
    for pkg_name in conf.args.pkgs:
        pkg = package.pkg_cache[pkg_name]
        print(pkg.str())
        if conf.args.release == 'all':
            print('  channels:')
            for channel_name,channel in pkg.channels.items():
                print('    ' + channel.name + ':')
                print('      releases:')
                for release_name,release in channel.releases.items():
                    print('        ' + release.name)
        else:
            release = pkg.selected_release()
            print('  ' + release.name)
                    

def add_pkgs_args(parser):
    parser.add_argument('--channel',default='stable')
    parser.add_argument('--activate-serial-number', action='store_true')
    parser.add_argument('--release',default='latest')
    parser.add_argument('--repo-pkg',default='psxe')
    parser.add_argument('pkgs',nargs='+')
    
def add_parser(cmd_parsers):
    package_parser = cmd_parsers.add_parser('pkg')
    package_action_parser = package_parser.add_subparsers(dest='pkg_action')

    package_list_parser = package_action_parser.add_parser('list',help='list available packages')
    package_list_parser.set_defaults(func=_pkg_list)

    package_info_parser = package_action_parser.add_parser('info',help='Info about a package')
    add_pkgs_args(package_info_parser)
    package_info_parser.set_defaults(func=_pkg_info)

    package_install_parser = package_action_parser.add_parser('install',help='install a package')
    add_pkgs_args(package_install_parser)
    package_install_parser.add_argument('--install-dir', default='/opt/intel')
    package_install_parser.set_defaults(func=_pkg_install)

    package_uninstall_parser = package_action_parser.add_parser('uninstall',help='uninstall a package')
    add_pkgs_args(package_uninstall_parser)
    package_uninstall_parser.add_argument('--install-dir', default='/opt/intel')
    package_uninstall_parser.set_defaults(func=_pkg_install)

