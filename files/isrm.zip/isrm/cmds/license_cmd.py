def _license_install(args):
    print('Installing a license')

# Public functions

def add_parser(object_parsers):
    package_parser = object_parsers.add_parser('license')
    package_action_parser = package_parser.add_subparsers(dest='license_action')

    package_install_parser = package_action_parser.add_parser('install',help='install a license')
    package_install_parser.set_defaults(func=_license_install)
