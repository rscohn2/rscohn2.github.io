# Standard Library

# Local
from .. import conf
from .. import installer
from .. import util

def add_yum_repo(args):
    # Add the key
    util.run('yum-config-manager --add-repo https://yum.repos.intel.com/setup/intelproducts.repo')
    
def add_apt_repo(args):
    # Add the key
    util.run('yum-config-manager --add-repo')
    
def _add_repo(args):
    if args.repo_type == 'yum':
        add_yum_repo(args)
    elif args.repo_type == 'apt':
        add_apt_repo(args)
    else:
        assert False

def _install_repo(args):
    '''Install a repo locally'''
    installer.fetch(conf.args.repo_pkg, download_offline=True, download_online=False)

    
def add_parser(cmd_parsers):
    repo_parser = cmd_parsers.add_parser('repo')
    repo_action_parser = repo_parser.add_subparsers(dest='repo_action')

    repo_install_parser = repo_action_parser.add_parser('install', help='install a repo locally')
    repo_install_parser.add_argument('--channel',default='stable')
    repo_install_parser.add_argument('--release',default='latest')
    repo_install_parser.add_argument('--repo-pkg',default='psxe')
    repo_install_parser.set_defaults(func=_install_repo)
