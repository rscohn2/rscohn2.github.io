# Standard Library
import shutil
import sys
import tempfile

# Local
from . import conf
from . import parser
from . import package
from . import util

def set_up(args=sys.argv[1:]):
    p = parser.IsrmParser()
    conf.args = p.parse_args(args)
    util.log('Parsed args: ' + str(conf.args))
    if 'func' not in conf.args:
        p.print_help()
        sys.exit(1)
    conf.tmp_dir = conf.args.tmp_dir if conf.args.tmp_dir else tempfile.mkdtemp()
    package.pkg_cache = package.PkgCache()
    
def execute_cmd():
    conf.args.func(conf.args)

def tear_down():
    if not conf.args.tmp_dir:
        shutil.rmtree(conf.tmp_dir)
    pkg_d = None

def main(args=sys.argv[1:]):
    set_up(args)
    execute_cmd()
    tear_down()
