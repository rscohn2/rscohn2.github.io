# Standard Library

# Local
from isrm import util

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class TestUtil(IsrmTestCase):
    def test_run(self):
        util.run('ls')
