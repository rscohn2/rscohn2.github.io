# Standard Library

# Local
from isrm import cache

from .isrm_unittest import IsrmTestCase

class TestCache(IsrmTestCase):
    def test_cache_clear(self):
        cache.clear()
