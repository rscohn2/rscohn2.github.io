# Standard Library
import unittest

# Local
from isrm import main

verbose = False
#verbose = True

class IsrmTestCase(unittest.TestCase):
    def setUp(self):
        args = ['info']
        if verbose:
            args.insert(0,'--verbose')
        main.set_up(args)

    def tearDown(self):
        main.tear_down()

class IsrmTestCmd(IsrmTestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def execute_cmd(self,args):
        if verbose:
            args.insert(0,'--verbose')
        main.main(args)
