# Standard Library

# Local
from isrm import cache
from isrm import conf
from isrm import installer

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class TestInstaller(IsrmTestCase):
    def test_fetchInstaller(self):
        # Slows down testing
        # cache.clear()
        conf.args.channel = 'stable'
        conf.args.release = 'latest'
        installer.fetch('psxe', download_offline=False, download_online=True)
