from setuptools import find_packages,setup

setup(name='isrm',
      description='Intel Software Repository Manager',
      author='Robert Cohn',
      author_email='Robert.S.Cohn@intel.com',
      license='Apache2',
      install_requires=[
          'pyyaml'
      ],
      entry_points = {'console_scripts': ['isrm=isrm.main:main']},
      packages=find_packages(),
      package_data={'isrm': ['data/*/*.yml','data/cfg/*']}
)
