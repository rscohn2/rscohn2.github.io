# Standard Library

# Local

_repo_names = ['yum','apt','irc']

class Repo:
    def __init__(self,d=None):
        if d:
            name = d['name']
            assert name in _repo_names

