# Standard Library
import os
from os import path
import shutil

# Local
from . import conf

def clear():
    if path.exists(conf.args.cache_dir):
        shutil.rmtree(conf.args.cache_dir)
    
def make_dir(id):
    dir = path.join(conf.args.cache_dir,id)
    if not path.exists(dir):
        os.makedirs(dir)
    return dir
        
def installer_path(uri):
    '''Cache path for installer'''
    dir = make_dir('installer')
    return path.join(dir,path.basename(uri))

def unpacked_installer_path(uri):
    '''Cache path for unpacked installer'''
    dir = make_dir('unpacked_installer')
    return path.join(dir,path.basename(uri))

def pkg_path(id):
    '''Package path for pkgs'''
    dir = make_dir('pkg')
    return path.join(dir,id)
