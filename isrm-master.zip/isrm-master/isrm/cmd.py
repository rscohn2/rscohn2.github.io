# Standard Library

# Local
from .cmds import cache_cmd
from .cmds import info_cmd
from .cmds import license_cmd
from .cmds import pkg_cmd
from .cmds import repo_cmd

cmds = [pkg_cmd, license_cmd, repo_cmd, info_cmd, cache_cmd]

def add_arguments(parser):
    cmd_parsers = parser.add_subparsers(dest='cmd', help='cmds')
    for cmd in cmds:
        cmd.add_parser(cmd_parsers)


