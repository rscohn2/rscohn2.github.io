# Standard Library

# Local
from .. import cache
from .. import conf

def _clear_cache(args):
    '''Clear the cache'''
    cache.clear()
    
def add_parser(cmd_parsers):
    cache_parser = cmd_parsers.add_parser('cache')
    cache_action_parser = cache_parser.add_subparsers(dest='cache_action')

    cache_clear_parser = cache_action_parser.add_parser('clear', help='clear the cache')
    cache_clear_parser.set_defaults(func=_clear_cache)
