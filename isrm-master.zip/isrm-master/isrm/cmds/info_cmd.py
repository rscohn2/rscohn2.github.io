# Standard Library

# Local


def _info_cmd(args):
    return

def add_parser(cmd_parsers):
    info_parser = cmd_parsers.add_parser('info')
    info_parser.set_defaults(func=_info_cmd)
