# Standard Library
from os import path
import subprocess
import sys

# Local
from . import conf

#
# Logging
#
def log(message):
    '''Log a message for debugging'''
    if conf.args.verbose:
        print(sys._getframe(1).f_code.co_name,': ',message)

#
# Error handling
#
def error(message):
    sys.stderr.write(message + '\n')
    sys.exit(1)

#
# Processes
#
def run(cmd,**kwargs):
    log(cmd)
    if not conf.args.dry_run:
        subprocess.check_call(cmd, **kwargs)
