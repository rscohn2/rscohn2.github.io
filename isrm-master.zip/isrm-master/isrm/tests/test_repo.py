# Standard Library

# Local
from isrm import conf
from isrm import repo

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class TestRepo(IsrmTestCase):
    def test_constructors(self):
        good_dicts = [{'name': 'yum'},{'name': 'apt'},{'name': 'irc'}]
        for d in good_dicts:
            with self.subTest(d['name']):
                repo.Repo(d)
