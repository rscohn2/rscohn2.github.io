# Standard Library

# Local

from .isrm_unittest import IsrmTestCase,IsrmTestCmd

class Cmd(IsrmTestCmd):
    def test_info(self):
        self.execute_cmd(['info'])
